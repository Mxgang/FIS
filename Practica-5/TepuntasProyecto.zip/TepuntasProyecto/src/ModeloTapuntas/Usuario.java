/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author aanaya
 */
class Usuario {
    private String nombreUsuario;
    private String contrasena;
    private String direccionCorreo;
    
    private boolean visibilidad = false;
    private boolean pendienteBaja = false;
    
    // datos perfil
    private String nombre;
    private String telefono;
    private String breveDescripcionPersonal;
    TipoTransaccion preferenciaCobro;
    
    // datos taPuntas
    private Map<String,Vehiculo> vehiculos = new HashMap();
    private List<PlanAlquiler> planes = new ArrayList();

    Usuario(String nombreUsuario, String contrasena, String direccionCorreo) {
      this.nombreUsuario= nombreUsuario;
      this.contrasena = contrasena;
      this.direccionCorreo = direccionCorreo;
    }
    
    protected void modificarVisibilidad(boolean visible){
        this.visibilidad = visible;
    }
    
    protected void nuevoVehiculo(String matricula, String marca, String modelo, String color, String confor, String categoria, int numeroPlazas) throws Exception{
        if(vehiculos.containsKey(matricula)) throw new Exception("ya existe un vehiculo con esa matricula");
       vehiculos.put(matricula, new Vehiculo(matricula,marca,modelo, color, confor, categoria, numeroPlazas));
    }
    
    protected List<PlanAlquiler> obtenerPlanesQueCumplanRequisitos(String ciudadRecogida, GregorianCalendar fechaInicio, GregorianCalendar fechaFin){
        List<PlanAlquiler> planesQueNosValen = new ArrayList();
        
        //PlanAlquiler planAux;
        List<GregorianCalendar> fechasAux;
        for ( PlanAlquiler i : planes){
            fechasAux = i.obtenerFechasPA();
            if (i.obtenerCiudad().equals(ciudadRecogida) &&
                ((fechaInicio.after(fechasAux.get(0)) && fechaInicio.before(fechasAux.get(1))) || (fechaFin.before(fechasAux.get(1)) && fechaFin.after(fechasAux.get(0))) || fechaFin.after(fechasAux.get(1)) && fechaInicio.before(fechasAux.get(0))))
                    planesQueNosValen.add(i);
        }
        
        return planesQueNosValen;
    }
    
    protected void definirPlanAlquiler(GregorianCalendar primerDiaAlquiler, GregorianCalendar ultimoDiaAlquiler, double costeAlquilerAlDia, String ciudadRecogida, String matricula) throws Exception{
        if(!vehiculos.containsKey(matricula)) 
            throw new Exception("no existe un vehiculo con esa matricula");
        else {
            this.planes.add(new PlanAlquiler(primerDiaAlquiler,ultimoDiaAlquiler,costeAlquilerAlDia,ciudadRecogida,vehiculos.get(matricula)));
            vehiculos.get(matricula).incluirPlanAlquiler(new PlanAlquiler(primerDiaAlquiler, ultimoDiaAlquiler, costeAlquilerAlDia, ciudadRecogida, vehiculos.get(matricula)));
        }
    }
    
    protected void eliminarVehiculo(String matricula) throws Exception{
        if(!vehiculos.containsKey(matricula)) throw new Exception("no existe un vehiculo con esa matrícula");
        this.vehiculos.remove(matricula);
    }
    
    protected void introducirPerfil(String nombre, String telefono, String breveDescripcion, TipoTransaccion tipo){
        this.nombre = nombre;
        this.telefono = telefono;
        this.breveDescripcionPersonal = breveDescripcion;
        this.preferenciaCobro = tipo;
    }
    
    protected List obtenerPlanesAlquiler(){
        List<List<String>> listaPlanes = new ArrayList();
        SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
        for(int i = 0; i<this.planes.size(); i++){
            listaPlanes.add(new ArrayList());
            fmt.setCalendar(planes.get(i).obtenerFechasPA().get(0));
            String dateFormatted = fmt.format(planes.get(i).obtenerFechasPA().get(0).getTime());
            listaPlanes.get(i).add(dateFormatted);
            fmt.setCalendar(planes.get(i).obtenerFechasPA().get(1));
            dateFormatted = fmt.format(planes.get(i).obtenerFechasPA().get(1).getTime());
            listaPlanes.get(i).add(dateFormatted);
            listaPlanes.get(i).add(planes.get(i).obtenerDatosPA().get(0));
            listaPlanes.get(i).add(planes.get(i).obtenerDatosPA().get(1));
        }
        
        return listaPlanes;
    }
    
    protected List consultarPerfil(){
        List<String> datosPerfil = new ArrayList();
        datosPerfil.add(nombre);
        datosPerfil.add(telefono);
        datosPerfil.add(breveDescripcionPersonal);
        datosPerfil.add(preferenciaCobro.toString());        
        return datosPerfil;
    }
    
    protected String getNombreUsuario(){
        return this.nombreUsuario;
    }
    
    
    protected Vehiculo buscarVehiculo(String matricula) throws Exception{
        if(!vehiculos.containsKey(matricula)) 
            throw new Exception("no existe un vehiculo con esa matricula");
        else 
            return this.vehiculos.get(matricula);
    }
    
    protected List matriculasVehiculos(){
        List<String> matriculas = new ArrayList();
        matriculas.addAll(vehiculos.keySet());
        return matriculas;
    }
    
}
