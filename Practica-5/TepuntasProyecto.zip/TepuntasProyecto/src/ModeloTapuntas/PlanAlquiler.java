/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

/**
 *
 * @author Maxigang
 */
class PlanAlquiler {
    private GregorianCalendar primerDiaAlquiler;
    private GregorianCalendar ultimoDiaAlquiler;
    
    private boolean visible;
    
    private double costeAlquilerAlDia;
    private String ciudadRecogida;
    
    private Vehiculo vehiculo;
    
    protected PlanAlquiler(GregorianCalendar primerDiaAlquiler, GregorianCalendar ultimoDiaAlquiler, double costeAlquilerAlDia, String ciudadRecogida, Vehiculo vehiculo) {
        this.primerDiaAlquiler = primerDiaAlquiler;
        this.ultimoDiaAlquiler = ultimoDiaAlquiler;
        this.visible = true;
        this.costeAlquilerAlDia = costeAlquilerAlDia;
        this.ciudadRecogida = ciudadRecogida;
        this.vehiculo = vehiculo;
    }
    
    protected List<GregorianCalendar> obtenerFechasPA(){
        List<GregorianCalendar> fechasPA = new ArrayList();
        fechasPA.add(primerDiaAlquiler);
        fechasPA.add(ultimoDiaAlquiler);
        return fechasPA;
    }
    
    protected List<String> obtenerDatosPA(){
        List<String> datosPA = new ArrayList();
        datosPA.add(Double.toString(costeAlquilerAlDia));
        datosPA.add(ciudadRecogida);
        return datosPA;
    }
    
    protected void eliminarVehiculo(){
        this.vehiculo = null;
    }
    
    protected void asignarVehiculo(Vehiculo vehiculo){
        this.vehiculo = vehiculo;
    }
    
    protected boolean tieneVehiculoAsignado(){
        return (this.vehiculo != null);
    }
    
    protected void modificarVisibilidad(boolean visible){
        this.visible = visible;
    }
    
    protected String obtenerCiudad(){
        return this.ciudadRecogida;
    }
}
