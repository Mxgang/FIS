/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

/**
 *
 * @author Maxigang
 */
class Vehiculo {
    private String matricula;
    
    private String marca;
    private String modelo;
    private String color;
    private String confor;
    private String categoria;
    private int numeroPlazas;
    
    private List<PlanAlquiler> planes = new ArrayList();
    
    protected Vehiculo(String matricula, String marca, String modelo, String color, String confor, String categoria, int numeroPlazas) {
      this.matricula= matricula;
      this.marca = marca;
      this.modelo = modelo;
      this.color= color;
      this.confor = confor;
      this.categoria = categoria;
      this.numeroPlazas = numeroPlazas;
    }
    
    protected List obtenerDatosVehiculo(){
        List<String> datosVehiculo = new ArrayList();
        datosVehiculo.add(matricula);
        datosVehiculo.add(modelo);
        datosVehiculo.add(color);
        datosVehiculo.add(confor);
        datosVehiculo.add(categoria);
        datosVehiculo.add(Integer.toString(numeroPlazas));
        return datosVehiculo;
    }
    
    protected boolean estasDisponible(GregorianCalendar inicio, GregorianCalendar fin){
        boolean disponibilidad = true;
        
        List<GregorianCalendar> fechasAux;
        for ( PlanAlquiler i : planes){
            fechasAux = i.obtenerFechasPA();
            if ((inicio.after(fechasAux.get(0)) && inicio.before(fechasAux.get(1))) || (fin.before(fechasAux.get(1)) && fin.after(fechasAux.get(0))))
                disponibilidad = false;
        }
        
        return disponibilidad;
    }
    
    protected void incluirPlanAlquiler(PlanAlquiler plan){
        this.planes.add(plan);
    }
    
    protected boolean tieneAlquileres(){
        return !this.planes.isEmpty();
    }
    
    protected void eliminarVehiculoAlquileres(){
        this.planes.clear();
    }
    
    protected String obtenerMatricula(){
        return this.matricula;
    }
}
