/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author aanaya
 */
public class Tapuntas {
    private static Tapuntas instanciaSingleton;
    private Map<String,Usuario> usuarios = new HashMap();
    

    // Este método mo está bien, está hecho para probar, tenéis que implementar el singleton
    public static Tapuntas getInstance() {
        if (instanciaSingleton == null)
            instanciaSingleton = new Tapuntas();
        return instanciaSingleton;
    }

    public void altaRegistro(String nombreUsuario, String contrasena, String direccionCorreo) throws Exception {
       if(usuarios.containsKey(nombreUsuario)) throw new Exception("ya existe un usuario con ese nombre de usuario");
       else usuarios.put(nombreUsuario, new Usuario(nombreUsuario,contrasena,direccionCorreo));
    }
    
    public void anadirVehiculo(String nombreUsuario, String matricula, String marca, String modelo, String color, String confor, String categoria, int numeroPlazas) throws Exception{
        if(!usuarios.containsKey(nombreUsuario)) throw new Exception("no existe un usuario con ese nombre de usuario");
        else usuarios.get(nombreUsuario).nuevoVehiculo(matricula, marca, modelo, color, confor, categoria, numeroPlazas);
    }
    
    public void anadirPlan(String nombreUsuario,String matricula,GregorianCalendar fechaInicio,GregorianCalendar fechaFin,double coste,String ciudad) throws Exception{
        if(!usuarios.containsKey(nombreUsuario)) throw new Exception("no existe un usuario con ese nombre de usuario");
        else
            usuarios.get(nombreUsuario).definirPlanAlquiler(fechaInicio, fechaFin, coste, ciudad, matricula);
    }
    
    public void eliminarVehiculo(String nombreUsuario, String matricula) throws Exception{
        if(!usuarios.containsKey(nombreUsuario)) throw new Exception("no existe un usuario con ese nombre de usuario");
        else usuarios.get(nombreUsuario).eliminarVehiculo(matricula);
    }
    
    public List<String> consultarVehiculos(String nombreUsuario) throws Exception{
        if(!usuarios.containsKey(nombreUsuario)) throw new Exception("no existe un usuario con ese nombre de usuario");
       else return usuarios.get(nombreUsuario).matriculasVehiculos();
    }
    
    public List<List<String>> consultarPlanesUsuario(String nombreUsuario) throws Exception{
        if(!usuarios.containsKey(nombreUsuario)) throw new Exception("no existe un usuario con ese nombre de usuario");
        else return usuarios.get(nombreUsuario).obtenerPlanesAlquiler();
    }
    
    public List<List<String>> obtenerAlquileresEnCiudadYFecha(String ciudadRecogida, GregorianCalendar fechaInicio,GregorianCalendar fechaFin) {
        List<List<String>> alquileresEncontrados = new ArrayList();
        
        List<PlanAlquiler> planesEncontrados = new ArrayList();
        for (Map.Entry<String, Usuario> entry : usuarios.entrySet()){
            planesEncontrados.addAll(entry.getValue().obtenerPlanesQueCumplanRequisitos(ciudadRecogida, fechaInicio, fechaFin));
        }
        
        
        SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
        int i = 0;
        for (PlanAlquiler p : planesEncontrados){
            alquileresEncontrados.add(new ArrayList());
            fmt.setCalendar(p.obtenerFechasPA().get(0));
            String dateFormatted = fmt.format(p.obtenerFechasPA().get(0).getTime());
            alquileresEncontrados.get(i).add(dateFormatted);
            fmt.setCalendar(p.obtenerFechasPA().get(1));
            dateFormatted = fmt.format(p.obtenerFechasPA().get(1).getTime());
            alquileresEncontrados.get(i).add(dateFormatted);
            alquileresEncontrados.get(i).add(p.obtenerDatosPA().get(0));
            alquileresEncontrados.get(i).add(p.obtenerDatosPA().get(1));
            i++;
        }
        
        return alquileresEncontrados;
    }
    
    public List obtenerNombresUsuarios() throws Exception{
        List<String> nombresUsuarios = new ArrayList();
        
        usuarios.entrySet().stream().forEach((e) -> {
            nombresUsuarios.add(((Usuario) e.getValue()).getNombreUsuario());
        });
        
        if (nombresUsuarios.isEmpty())
            throw new Exception("Aún no hay usuarios registrados");
        
        return nombresUsuarios;
    }
    
    public void introducirPerfil(String nombreUsuario, String nombre, String telefono, String breveDescripcion, String tipo) throws Exception {
       TipoTransaccion tipoE = TipoTransaccion.valueOf(tipo);
       if(!usuarios.containsKey(nombreUsuario)) throw new Exception("no existe un usuario con ese nombre de usuario");
       else usuarios.get(nombreUsuario).introducirPerfil(nombre, telefono, breveDescripcion, tipoE);
    }
    
    public List consultarPerfil(String nombreUsuario) throws Exception{
       if(!usuarios.containsKey(nombreUsuario)) throw new Exception("no existe un usuario con ese nombre de usuario");
       else return usuarios.get(nombreUsuario).consultarPerfil();
    }
    
    // buscarOfertasAlquiler
    
}
