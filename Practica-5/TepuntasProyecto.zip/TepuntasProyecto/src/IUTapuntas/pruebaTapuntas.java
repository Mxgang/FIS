/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IUTapuntas;

import ModeloTapuntas.Tapuntas;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author aanaya
 */
public class pruebaTapuntas {

    /**
     * @param args the command line arguments
     */
    static Scanner in;
    
    public static void main(String[] args) {
        
     
        // Obtener la única instancia de la clase BuenProvecho (patrón sigleton)
        Tapuntas aViajar = Tapuntas.getInstance(); 
        
        // Definir la variable que nos permite leer String desde teclado
        in = new Scanner(System.in);
        int opcion = 0; 
        do{
            try{ // tratamiento de las excepciones. Bloque try en el que se puede producir una excepción y la capturamos
		 
                 //Terminar de diseñar el menú (usando System.out.println(...)) con las opciones que faltan
		 // Podéis hacer vuestros propios diseños de interfaz, esta es la interfaz mínima que tenéis que entregar
                System.out.println("\n\n*********************************** MENU ***********************************\n" +
                                       "GESTIÓN DE USUARIOS   \n" +
                                     "\t10. Nuevo Usuario \n" +
                                     "\t11. Consultar usuarios del sistema \n" +
                                     "\t12. Actualizar Perfil de Usuario \n" +
                                     "\t13. Consultar Perfil de un Usuario \n");	
                                 
                System.out.println("GESTIÓN DE VEHICULOS  \n" +                             
                                    "\t20. Nuevo vehículo \n" +
                                    "\t21. Consultar vehículos de un usuario \n" +
                                    "\t22. Eliminar vehículo\n");
                
                System.out.println("GESTIÓN DE PLANES DE ALQUILER  \n" +
                                    "\t30. Definir nuevo plan de alquiler \n" +
                                    "\t31. Consultar planes de alquiler de un usuario\n" +
                                    "\t32. Buscar ofertas de planes de alquiler \n");
                
                System.out.println("\n**********************************************************************");
                		         
                System.out.println("\t0. TERMINAR");
		System.out.println("\n**********************************************************************");
                 
                // Lectura de un int, para darle valor a opcion.
                opcion =Integer.parseInt(in.nextLine()); 
                
                // Estructura switch con todas las opciones de menú. Algunos de ellos ya lo tenéis hecho
                // Tenéis que terminar las opciones que están incompletas y las que no están hechas
               
                switch(opcion){
                    case 10: //incluir un nuevo usuario en el sistema 
                                            
                        System.out.print("Nombre de usuario:");
                        String nombreUsuario =in.nextLine();
                                       
                        System.out.print("Clave:");
                        String claveUsuario= in.nextLine();
                        
                        System.out.print("Dirección de correo:");
                        String correoUsuario= in.nextLine();
                        
                        aViajar.altaRegistro(nombreUsuario, claveUsuario, correoUsuario);                                             
                        System.out.println("++++++  Operación realizada con éxito  ++++++");
                        pressAnyKeyToContinue();
                    break;  
                    
                    case 11:/*Ver usuarios del sistema */
                        
                        System.out.println("Lista de usuarios registrados: ");
                        List<String> nombresUsuarios = aViajar.obtenerNombresUsuarios();
                        for (String i : nombresUsuarios )
                            System.out.println("\t" + i);
                        pressAnyKeyToContinue();
                                                                     
                    break;
                    
                    case 12:/*Incluir Perfil */
                                                   
                        System.out.print("Introduce el usuario al que actualizar el perfil:");
                        String nombreUsuarioAModificarPerfil = in.nextLine();
                        
                        System.out.print("Nombre:");
                        String nombre =in.nextLine();
                                       
                        System.out.print("Telefono:");
                        String telefono= in.nextLine();
                        
                        System.out.print("Descripcion:");
                        String descripcion= in.nextLine();
                        
                        System.out.println("Tipo de pago preferido (1-4):");
                        System.out.println("\t1: PAYPAL");
                        System.out.println("\t2: TARJETA");
                        System.out.println("\t3: EFECTIVO");
                        System.out.println("\t4: TRANSFERENCIA");
                        String tipoElegido= in.nextLine();
                        String tipo;
                        switch(tipoElegido){
                            case "1":
                                tipo = "PAYPAL";
                                break;
                            case "2":
                                tipo = "TARJETA";
                                break;
                            case "3":
                                tipo = "EFECTIVO";
                                break;
                            case "4":
                                tipo = "TRANSFERENCIA";
                                break;
                            default:
                                System.out.println("Error: opción de pago errónea. Se seteará la opción por defecto PAYPAL.");
                                tipo = "PAYPAL";
                                break;
                        }            
                        aViajar.introducirPerfil(nombreUsuarioAModificarPerfil, nombre, telefono, descripcion, tipo);
                        System.out.println("++++++  Operación realizada con éxito  ++++++");
                        pressAnyKeyToContinue();
                        
                    break;
                    case 13:/*Consultar perfil */
                        
                        System.out.print("Introduce el usuario al que consultar el perfil:");
                        String nombreUsuarioAConsultarPerfil = in.nextLine();
                        
                        List<String> datosUsuario = aViajar.consultarPerfil(nombreUsuarioAConsultarPerfil);
                        
                        System.out.println("\t Nombre: " + datosUsuario.get(0));
                        System.out.println("\t Telefono: " + datosUsuario.get(1));
                        System.out.println("\t Descripcion: " + datosUsuario.get(2));
                        System.out.println("\t Tipo de pago preferido: " + datosUsuario.get(3));
                        
                        System.out.println("++++++  Operación realizada con éxito  ++++++");
                        pressAnyKeyToContinue();
                        
                    break;
                
                    case 20: /*Nuevo vehículo */    
                        
                        System.out.print("Introduce el usuario al que añadir un vehiculo:");
                        String nombreUsuarioAAnadirVehiculo = in.nextLine();
                        
                        System.out.print("Matricula:");
                        String matricula =in.nextLine();
                                       
                        System.out.print("Marca:");
                        String marca= in.nextLine();
                        
                        System.out.print("Modelo:");
                        String modelo= in.nextLine();
                        
                        System.out.print("Color:");
                        String color= in.nextLine();
                        
                        System.out.print("Confor:");
                        String confor= in.nextLine();
                        
                        System.out.print("Categoria:");
                        String categoria= in.nextLine();
                        
                        System.out.print("Plazas:");
                        int plazas= Integer.parseInt(in.nextLine());
                        
                        aViajar.anadirVehiculo(nombreUsuarioAAnadirVehiculo, matricula, marca, modelo, color, confor, categoria, plazas);
                        
                        System.out.println("++++++  Operación realizada con éxito  ++++++");
                        pressAnyKeyToContinue();
                                                     
                    break;
                  
                    case 21: /* Consultar vehículos de un usuario  */
                        
                        System.out.print("Introduce el usuario al que consultar sus vehiculos:");
                        String nombreUsuarioAConsultarVehiculos = in.nextLine();
                        
                        List<String> matriculasVehiculosUsuario = aViajar.consultarVehiculos(nombreUsuarioAConsultarVehiculos);
                        
                        for (String i : matriculasVehiculosUsuario )
                            System.out.println("\t" + i);
                        pressAnyKeyToContinue();
                                                   
                    break;             
                  
                    case 22: /* Eliminar vehículo  */
                        
                        System.out.print("Introduce el usuario al que eliminar algún vehículo:");
                        String nombreUsuarioAEliminarVehiculo = in.nextLine();
                        
                        System.out.print("Introduce la matrícula del vehículo a eliminar:");
                        String matriculaAEliminar = in.nextLine();
                        
                        aViajar.eliminarVehiculo(nombreUsuarioAEliminarVehiculo,matriculaAEliminar);
                        
                        System.out.println("++++++  Operación realizada con éxito  ++++++");
                        pressAnyKeyToContinue();
                                                    
                    break;
  
    
                    case 30: /* Nuevo plan de alquiler */
                        
                        System.out.print("Introduce el usuario al que añadir un plan de alquiler:");
                        String nombreUsuarioAAnadirPlan = in.nextLine();
                        
                        System.out.print("Introduce la matrícula del vehículo a ofertar:");
                        String matriculaAAnadirPlan = in.nextLine();
                        
                        DateFormat format = new SimpleDateFormat("dd-MM-yyyy",Locale.US);
                        System.out.println("Introduce las fechas con este formato: dd-MM-yyyy");
                        System.out.println("Por ejemplo, hoy es: " + format.format(new Date()));
                        System.out.print("Introduce la fecha de inicio: ");
                        Date date = null;
                        while (date == null) {
                            String line = in.nextLine();
                            try {
                                date = format.parse(line);
                            } catch (ParseException e) {
                                System.out.println("Error: el formato de la fecha no es correcto.");
                            }
                        }
                        GregorianCalendar fechaInicio = new GregorianCalendar();
                        fechaInicio.setTime(date);
                        System.out.print("Introduce la fecha de fin: ");
                        date = null;
                        while (date == null) {
                            String line = in.nextLine();
                            try {
                                date = format.parse(line);
                            } catch (ParseException e) {
                                System.out.println("Error: el formato de la fecha no es correcto.");
                            }
                        }
                        GregorianCalendar fechaFin = new GregorianCalendar();
                        fechaFin.setTime(date);
                        
                        System.out.print("Coste del alquiler por día:");
                        double coste= Double.parseDouble(in.nextLine());
                        
                        System.out.print("Introduce la ciudad de recogida:");
                        String ciudad= in.nextLine();
                        
                        aViajar.anadirPlan(nombreUsuarioAAnadirPlan,matriculaAAnadirPlan,fechaInicio,fechaFin,coste,ciudad);
                        System.out.println("++++++  Operación realizada con éxito  ++++++");
                        pressAnyKeyToContinue();
                        
                    break;

                    case 31: /* Consultar planes de alquiler de un usuario */
                                                
                        System.out.print("Introduce el usuario al que consultar sus planes de alquiler:");
                        String nombreUsuarioAConsultarPlanes = in.nextLine();
                        
                        List<List<String>> planes = aViajar.consultarPlanesUsuario(nombreUsuarioAConsultarPlanes);
                        
                        for (List i : planes ){
                            System.out.println("-----------");
                            System.out.println("Fecha inicio: " + i.get(0));
                            System.out.println("Fecha fin: " + i.get(1));
                            System.out.println("Precio por día: " + i.get(2));
                            System.out.println("Ciudad de recogida: " + i.get(3));
                        }   System.out.println("-----------");
                        pressAnyKeyToContinue();
                        
                        
                        
                    break;

                    case 32: /* Buscar ofertas de planes de alquiler  */
                        
                        System.out.print("Introduce la ciudad en la que quieres recoger el vehiculo:");
                        String ciudadRecogida = in.nextLine();
                        
                        DateFormat formatBusqueda = new SimpleDateFormat("dd-MM-yyyy",Locale.US);
                        System.out.println("Introduce un periodo de búsqueda de fechas con este formato: dd-MM-yyyy");
                        System.out.println("Por ejemplo, hoy es: " + formatBusqueda.format(new Date()));
                        System.out.print("Introduce principio del periodo: ");
                        Date dateBusqueda = null;
                        while (dateBusqueda == null) {
                            String line = in.nextLine();
                            try {
                                dateBusqueda = formatBusqueda.parse(line);
                            } catch (ParseException e) {
                                System.out.println("Error: el formato de la fecha no es correcto.");
                            }
                        }
                        GregorianCalendar fechaInicioBusqueda = new GregorianCalendar();
                        fechaInicioBusqueda.setTime(dateBusqueda);
                        System.out.print("Introduce fin del periodo: ");
                        dateBusqueda = null;
                        while (dateBusqueda == null) {
                            String line = in.nextLine();
                            try {
                                dateBusqueda = formatBusqueda.parse(line);
                            } catch (ParseException e) {
                                System.out.println("Error: el formato de la fecha no es correcto.");
                            }
                        }
                        GregorianCalendar fechaFinBusqueda = new GregorianCalendar();
                        fechaFinBusqueda.setTime(dateBusqueda);
                        
                        System.out.println("Los planes encontrados son los siguientes:");
                        List<List<String>> planesEncontrados = aViajar.obtenerAlquileresEnCiudadYFecha(ciudadRecogida, fechaInicioBusqueda, fechaFinBusqueda);
                        for (List i : planesEncontrados ){
                            System.out.println("-----------");
                            System.out.println("Fecha inicio: " + i.get(0));
                            System.out.println("Fecha fin: " + i.get(1));
                            System.out.println("Precio por día: " + i.get(2));
                            System.out.println("Ciudad de recogida: " + i.get(3));
                        }   System.out.println("-----------");
                        pressAnyKeyToContinue();
                    break;                 

                    case 0: /* terminar */
                    break;                        
                                    
                    default:
                        System.out.println("opcion no válida");
                    break;
                }
//               
            }catch(Exception ex){ // captura de la excepción
                System.err.println("se ha producido la siguiente excepcion: "+ ex);
            } 
        }while(opcion !=0); 
        System.exit(0);
    }
    
     private static void pressAnyKeyToContinue(){ 
            System.out.println("Pulsa ENTER para continuar...");
            try
            {
                System.in.read();
            }  
            catch(Exception e)
            {}  
     }
     
     private static String seleccionarUsuario(List<String> listaUsuarios){ 
            int j = 0;
            Map<Integer,String> listaSeleccion = new HashMap();
            for (String i : listaUsuarios){
                System.out.println("\t" + j + ": " + i);
                j++;
                listaSeleccion.put(j, i);
            }
            
            System.out.print("Introduce el número del usuario que quieras seleccionar :");
            int usuarioSeleccionado = Integer.parseInt(in.nextLine());
            
            return listaSeleccion.get(usuarioSeleccionado);
     }

}

    
    

